--ADJUST AIRBOSS CARRIER OPS SETTINGS HERE

--CARRIER AVAILABLE SETTINGS
cv_cvn_enable = true
cv_lha_enable = true
cv_kuz_enable = true

--friendly carrier groups hold fire against enemy air
carrier_groups_hold_fire = true

--allow static deck objects to spawn on super carrier at mission start
enable_sc_cvn_deck_template_on_start = true


--AIRBOSS SETTINGS
airboss_enable = true

airboss_enable_markzones = true

airboss_enable_smokezones = true

airboss_enable_niceguy = true

airboss_enable_tanker = false
airboss_enable_rescue_helo = false

--DEFINE CARRIERS & AIRBOSS SETTINGS HERE