--SET MISSION ERA (determines air and ground spawns); "modern", "ww2", "korean_war", "cold_war" use true or false for asset pack, only set true if you own ww2 asset pack!

mission_era = "modern"
ww2_asset_pack_enable = false